package com.example.aula_6

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
